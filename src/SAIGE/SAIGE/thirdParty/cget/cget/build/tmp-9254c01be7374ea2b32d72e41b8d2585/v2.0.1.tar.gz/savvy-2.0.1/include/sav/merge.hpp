/*
 * This Source Code Form is subject to the terms of the Mozilla Public
 * License, v. 2.0. If a copy of the MPL was not distributed with this
 * file, You can obtain one at http://mozilla.org/MPL/2.0/.
 */

#ifndef SAVVY_SAV_MERGE_HPP
#define SAVVY_SAV_MERGE_HPP
#ifdef NEEDS_PORT_TO_SAV_V2
int merge_main(int argc, char** argv);
#endif
#endif //SAVVY_SAV_MERGE_HPP